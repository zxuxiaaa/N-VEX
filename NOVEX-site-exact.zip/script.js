let cart=JSON.parse(localStorage.getItem('novex-cart')||'[]');
function renderCart(){const box=document.getElementById('cartItems'),count=document.getElementById('cartCount'),total=document.getElementById('total');count.textContent=cart.length;if(!cart.length){box.innerHTML='<p class="muted">Ton panier est vide.</p>';total.textContent='0,00 €';return}let sum=0;box.innerHTML=cart.map((p,i)=>{sum+=p.price;return `<div class="cart-row"><span>${p.name}</span><strong>${p.price.toFixed(2).replace('.',',')} € <button class="remove" onclick="removeItem(${i})">×</button></strong></div>`}).join('');total.textContent=sum.toFixed(2).replace('.',',')+' €';}
function addToCart(name,price){cart.push({name,price});localStorage.setItem('novex-cart',JSON.stringify(cart));renderCart();toggleCart(true)}
function removeItem(i){cart.splice(i,1);localStorage.setItem('novex-cart',JSON.stringify(cart));renderCart()}
function toggleCart(force){const c=document.getElementById('cart'),o=document.getElementById('overlay');let open=force===true?true:!c.classList.contains('open');c.classList.toggle('open',open);o.classList.toggle('show',open)}
function checkout(){alert('Démo : connecte Stripe ou PayPal ici pour accepter les paiements.')}
function subscribe(e){e.preventDefault();document.getElementById('msg').textContent='Merci ! Tu seras prévenu du prochain drop.';e.target.reset()}
renderCart();
